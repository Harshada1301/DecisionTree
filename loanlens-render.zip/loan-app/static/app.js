(() => {
  const $ = (s) => document.querySelector(s);
  const form = $('#loanForm');
  const btn = $('#submitBtn');
  const errorBox = $('#error');
  const idle = $('#idle');
  const out = $('#out');
  const arc = $('#arc');
  const CIRC = 2 * Math.PI * 52;

  const required = [...form.querySelectorAll('[required]')];

  /* ---- progress bar + live loan-to-income ---- */
  function updateProgress() {
    const done = required.filter((el) => el.value !== '').length;
    $('#bar').style.width = Math.round((done / required.length) * 100) + '%';
  }

  function updateLpi() {
    const inc = parseFloat(form.person_income.value);
    const amt = parseFloat(form.loan_amnt.value);
    const val = $('#lpiVal');
    const bar = $('#lpiBar');
    if (inc > 0 && amt > 0) {
      const r = amt / inc;
      val.textContent = (r * 100).toFixed(0) + '%';
      bar.style.width = Math.min(r / 0.6, 1) * 100 + '%';
      bar.style.background = r <= 0.2 ? 'var(--ok)' : r <= 0.35 ? 'var(--warn)' : 'var(--bad)';
    } else {
      val.textContent = '--';
      bar.style.width = '0';
    }
  }

  form.addEventListener('input', (e) => {
    e.target.classList.remove('invalid');
    errorBox.hidden = true;
    updateProgress();
    updateLpi();
  });

  /* ---- helpers ---- */
  function countUp(el, to, ms = 1300) {
    const start = performance.now();
    const tick = (t) => {
      const p = Math.min((t - start) / ms, 1);
      const eased = 1 - Math.pow(1 - p, 4);
      el.textContent = (to * eased).toFixed(0);
      if (p < 1) requestAnimationFrame(tick);
      else el.textContent = Math.round(to);
    };
    requestAnimationFrame(tick);
  }

  function showError(msg) {
    errorBox.textContent = msg;
    errorBox.hidden = false;
  }

  function validate() {
    let first = null;
    required.forEach((el) => {
      let bad = el.value === '';
      if (!bad && el.type === 'number') {
        const v = parseFloat(el.value);
        bad = isNaN(v) || (el.min !== '' && v < +el.min) || (el.max !== '' && v > +el.max);
      }
      if (bad) {
        el.classList.remove('invalid');
        void el.offsetWidth; // restart shake animation
        el.classList.add('invalid');
        first = first || el;
      }
    });
    if (first) {
      first.focus();
      showError('Please complete the highlighted fields with valid values.');
      return false;
    }
    return true;
  }

  function render(data) {
    const ok = data.approved;
    const p = data.approval_probability;

    arc.classList.toggle('no', !ok);
    arc.style.transition = 'none';
    arc.style.strokeDashoffset = CIRC;
    idle.hidden = true;
    out.hidden = false;
    out.style.animation = 'none';
    void out.offsetWidth;
    out.style.animation = '';

    requestAnimationFrame(() => {
      arc.style.transition = '';
      arc.style.strokeDashoffset = CIRC * (1 - p / 100);
    });
    countUp($('#pct'), p);

    const v = $('#verdict');
    v.className = 'verdict ' + (ok ? 'ok' : 'no');
    v.textContent = ok ? 'Likely Approved' : 'Likely Rejected';
    $('#verdictSub').textContent = ok
      ? 'Your profile matches applicants who were typically approved.'
      : 'Your profile matches applicants who were typically declined. See the factors below.';

    const ul = $('#notes');
    ul.innerHTML = '';
    data.notes.forEach((n, i) => {
      const li = document.createElement('li');
      li.className = n.tone;
      li.textContent = n.text;
      li.style.animationDelay = 0.5 + i * 0.12 + 's';
      ul.appendChild(li);
    });

    if (window.matchMedia('(max-width: 920px)').matches) {
      out.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  /* ---- submit ---- */
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorBox.hidden = true;
    if (!validate()) return;

    btn.classList.add('loading');
    $('.btn-label').textContent = 'Analyzing...';

    const payload = Object.fromEntries(new FormData(form).entries());
    try {
      const res = await fetch('/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Something went wrong.');
      // short delay so the loading state is perceptible
      setTimeout(() => render(data), 350);
    } catch (err) {
      showError(err.message || 'Network error. Please try again.');
    } finally {
      setTimeout(() => {
        btn.classList.remove('loading');
        $('.btn-label').textContent = 'Check approval';
      }, 400);
    }
  });

  $('#resetBtn').addEventListener('click', () => {
    form.reset();
    out.hidden = true;
    idle.hidden = false;
    updateProgress();
    updateLpi();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  updateProgress();
})();
